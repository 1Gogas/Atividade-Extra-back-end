package com.example.gerenciadorprodutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorProdutosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GerenciadorProdutosApplication.class, args);
    }

}
